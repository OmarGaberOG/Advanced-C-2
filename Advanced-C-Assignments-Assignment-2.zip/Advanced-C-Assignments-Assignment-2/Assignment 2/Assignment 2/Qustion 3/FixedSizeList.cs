﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_2.Qustion_3
{
    internal class FixedSizeList<T> : IEnumerable<T>
    {
        public static int Capacity { get; set; }
        public List<T> list { get; set; }
        public FixedSizeList(int capacity)
        {
            if (capacity <= 0)
                throw new ArgumentException("Capacity must be greater than zero.");
            Capacity = capacity;
            list=new List<T>(capacity);
        }

        public void Add(T item)
        {
            if (list.Count >= Capacity)
                throw new InvalidOperationException("List is full! Cannot add more elements.");

            list.Add(item);
        }

        public T Get(int index)
        {
            if (index < 0 || index >= list.Count)
                throw new IndexOutOfRangeException("Invalid index.");

            return list[index];
        }
        public IEnumerator<T> GetEnumerator()
        {
            return list.GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
    }
}
