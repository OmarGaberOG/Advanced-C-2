﻿using Assignment_2.Qustion_3;
using System.Collections;

namespace Assignment_2
{
    internal class Program
    {
        #region 1.	You are given an ArrayList containing a sequence of elements. try to reverse the order of elements in the ArrayList in-place(in the same arrayList) without using the built-in Reverse. Implement a function that takes the ArrayList as input and modifies it to have the reversed order of elements.
        public static void ReverseList(ArrayList list)
        {
            Console.Write("After Reverse:");
            for (int i = list.Count - 1; i >= 0; i--)
            {
                Console.Write(list[i] + " ");
            }
        }
        #endregion

        #region 2.	You are given a list of integers. Your task is to find and return a new list containing only the even numbers from the given list.
        public static void EvenNumbers(List<int> list)
        {
            Console.Write("Even Numbers in list is : ( ");
            for (int i = 0; i < list.Count; i++)
            {
                if (list[i] % 2 == 0)
                {
                    Console.Write(list[i] + " ");
                }
            }
            Console.Write(")");
        }
        #endregion

        #region 4.	Given an array  consists of  numbers with size N and number of queries, in each query you will be given an integer X, and you should print how many numbers in array that is greater than  X.
        public static void GraterThan()
        {
            //Array
            int sizearray;
            do
            {
                Console.Write("Enter Size of array:");
            } while (!int.TryParse(Console.ReadLine(), out sizearray));
            List<int> array = new List<int>();
            Console.WriteLine("\nFill The array: ");
            Console.WriteLine("----------------");
            for (int i = 0; i < sizearray; i++)
            {
                int value;
                do
                {
                    Console.Write($"Enter element {i + 1}: ");
                } while (!int.TryParse(Console.ReadLine(), out value));

                array.Add(value);
            }
            Console.WriteLine();
            Console.WriteLine("----------------");
            Console.WriteLine("\nFill The Quary: ");
            Console.WriteLine("----------------");
            //Query
            int sizequary;
            do
            {
                Console.Write("Enter Size of Quary: ");
            } while (!int.TryParse(Console.ReadLine(), out sizequary));
            for (int i = 0; i < sizequary; i++)
            {
                int x;
                do
                {
                    Console.Write($"Enter element {i + 1}: ");
                } while (!int.TryParse(Console.ReadLine(), out x));
                int count = array.Count(num => num > x);
                Console.WriteLine($"Numbers greater than {x}: {count}");
            }
        }
        #endregion

        #region 5.	Given a number N and an array of N numbers. Determine if it's palindrome or not.
        public static void Palindrome(List<int> array)
        {
            bool isPalindrome = true;
            for (int i = 0; i < array.Count; i++)
            {
                if (array[i] != array[array.Count - 1 - i])
                {
                    isPalindrome = false;
                    break;
                }
            }
            if (isPalindrome)
                Console.WriteLine("Yes");
            else { Console.WriteLine("No"); }
        } 
        #endregion

        #region 6.	Given an array, implement a function to remove duplicate elements from an array.
        public static void RemoveDeplication(List<int> list)
        {
            for (int i = 0; i < list.Count; i++)
            {
                for (int j = i + 1; j < list.Count; j++)
                {
                    if (list[j] == list[i])
                    {
                        list.RemoveAt(j);
                    }
                }
                Console.WriteLine(list[i] + " ");
            }
        }
        #endregion

        #region 7.	 Given an array list , implement a function to remove all odd numbers from it.
        public static void RemoveOdd(List<int> list)
        {
            for (int i = 0; i < list.Count; i++)
            {
                if (list[i] % 2 != 0)
                {
                    list.Remove(list[i]);
                }
                Console.WriteLine(list[i] + " ");
            }
        } 
        #endregion
        static void Main(string[] args)
        {
            #region 1
            //ArrayList list = new ArrayList(new int[] { 5, 4, 3, 2, 1 });
            //ReverseList(list); 
            #endregion

            #region 2
            //List<int> list = new List<int>(new int[] { 1, 2, 3, 4, 56, 6, 88 });
            //EvenNumbers(list); 
            #endregion

            #region 3
            //FixedSizeList<int> myList = new FixedSizeList<int>(3);

            //myList.Add(10);
            //myList.Add(20);
            //myList.Add(30);

            //foreach (var item in myList)
            //{
            //    Console.Write(item+" ");
            //}

            ////myList.Add(40);

            ////foreach (var item in myList)
            ////{
            ////    Console.Write(item + " ");
            ////}
            //// Console.WriteLine(myList.Get(5));
            #endregion

            #region 4
            //GraterThan();
            #endregion

            #region 5
            //List<int> list = new List<int>(new int[] {1,2,3,2,1});
            //Palindrome(list); 
            #endregion

            #region 6
            //List<int> list = new List<int>(new int[] {1,2,3,3,4,5,5,6,6});
            //RemoveDeplication(list); 
            #endregion

            #region 7
            //List<int> list = new List<int>(new int[] { 1, 2, 3, 3, 4, 5, 6 });
            //RemoveOdd(list); 
            #endregion
        }
    }
}
